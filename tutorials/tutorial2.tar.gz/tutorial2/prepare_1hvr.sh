#!/bin/bash

#############################
# REQUIREMENTS
#############################
# pdb4amber
# SPORES_64bit
# antechamber

## Receptor
# Remove hydrogens from receptor and rename incompatible residues
# In this case, the residue CSO 67 should be converted to CYS automatically
pdb4amber -i rec/rec.pdb -o rec/rec_noH.pdb -y -p

# Reprotonate and convert to MOL2 with SPORES
SPORES_64bit --mode complete rec/rec_noH.pdb rec/rec_prot.mol2

## Ligand
# Reprotonate and convert to MOL2
SPORES_64bit --mode complete lig_preparation/lig.pdb lig_preparation/lig_prot.mol2
# Recompute gasteiger charges, rename to XK2, use sybyl atom types
antechamber -i lig_preparation/lig_prot.mol2 -fi mol2 -o lig_preparation/lig.mol2 -fo mol2 -c gas -nc 0 -rn XK2 -at sybyl -j 4 -s 2 -pf y
# Move the ligand to a new folder
mkdir -p lig
mv lig_preparation/lig.mol2 lig/lig.mol2 
