#!/bin/bash

mkdir -p {lig_preparation,rec}

grep "^ATOM" 1hvr.pdb > rec/rec.pdb
grep "^HETATM" 1hvr.pdb > lig_preparation/lig.pdb
